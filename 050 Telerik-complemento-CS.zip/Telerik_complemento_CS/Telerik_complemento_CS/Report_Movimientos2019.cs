namespace Telerik_complemento_CS
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using Telerik.Reporting;
    using Telerik.Reporting.Drawing;

    /// <summary>
    /// Summary description for Telerik_complemento.
    /// </summary>
    public partial class Report_Movimientos2019 : Telerik.Reporting.Report
    {
        public Report_Movimientos2019()
        {
            //
            // Required for telerik Reporting designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }
    }
}